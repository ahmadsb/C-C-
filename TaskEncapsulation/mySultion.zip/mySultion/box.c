#include"box.h"
#include<stdlib.h>
#include<stdio.h>




void init_box(box* b,double width, double height, double length){
    b->height = height;
    b->length = length;
    b->width = width;
}
box* create1_box(double width, double height, double length){
    box* b=(box*)malloc(sizeof(box));
    b->height = height;
    b->width = width;
    b->length = length;
    print(b);
    return b;
}
box* create2_box(double dim ){
    box* b =(box*)malloc(sizeof(box));
    b->height = dim;
    b->length =dim;
    b->width =dim;
    print(b);
    return b;
}
box* create_defualt_box( ){
    box* b =(box*)malloc(sizeof(box));
    b->height = 1;
    b->length =1;
    b->width =1;
    print(b);
    return b;
}
void delete_box(box* b){
   printf("Box destructor, %f x %f x %f\n", b->width, b->height, b->length);
//    free(b);
}


double const getVolume(box* b) {
    return b->width * b->length * b->height;
}
//pointer const
void mult(box* b,double mult){
    b->width *= mult;
    b->height *= mult;
    b->length *= mult;
}

void const print(box* b){
    printf("Box: %f x %f x %f\n", b->height, b->width, b->length); 
}

int equal(box* b1, box* b2){
    if(b1->height == b2->height &&
                 b1->length == b2->length &&
                         b1->width == b2->width)
                         return True;
    return False;
}
int not_equal(box* b1, box* b2){
    if (equal(b1,b2) == True)
        return False;
    return True;
}
void copy_ctor(box* b1 , box* b2){
    b1->height = b2->height;
    b1->width = b2->width;
    b1->length = b2->length;
    print(b1);
    print(b2);
}
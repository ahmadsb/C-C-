#include"shelf.h"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
// static void setMessage(shelf * s, char* msg)
// {
//     strcpy(s->message ,DEF_MSG);
// }

shelf* create_shelf(){
    shelf* s =(shelf*) malloc(sizeof(shelf));
    setMessage(s, DEF_MSG);
    for (int i = 0 ; i<NUM_BOXES ; i++){
        s->boxes[i] = create_defualt_box();
    }
    return s;
}
void setBox(shelf* s, int index, box* b){
    s->boxes[index] = b; //  copy constructor??
}
double const getVolumeOfShelf(shelf* s){
    double res = 0;
    
    for (int i = 0; i < NUM_BOXES; i++){
        res += getVolume(s->boxes[i]);
    }
    return res;
}

box* getBox(shelf* s, int index)
{
return s->boxes[index];
}

void const print_shelf(shelf* s){
printf("%s %f\n", s->message, getVolumeOfShelf(s));
}


#ifndef SHELF_H
#define SHELF_H
#include"box.h"
#include<string.h>


#define NUM_BOXES 3
#define SIZE_MSG 256
#define DEF_MSG "The total volume held on the shelf is"

typedef struct {
    //box without *
    box* boxes[NUM_BOXES];
    // char message[SIZE_MSG];
    char message[SIZE_MSG];
}shelf;
static void setMessage(shelf * s, char* msg)
{
    strcpy(s->message ,DEF_MSG);
}

shelf* create_shelf();

void setBox(shelf* s,int index, box* b);
double const getVolumeOfShelf();
box* getBox(shelf* s, int index);
void const print_shelf(shelf* s);

#endif






#ifndef BOX_H
#define BOX_H
#define True 1
#define False 0




typedef struct{
    double width;
    double height;
    double length;
    
}box;
void init_box(box* b,double width, double height, double length);
//void     pram box* b: Ctor init
box* create1_box( double width, double height, double length);
box* create2_box(double dim );
box* create_defualt_box();

void delete_box(box* b);
// pram: const box* const b
double  getVolume  (box * b ) ;

void mult(box* b, double mult);

void const print();


// Box operator*(const Box& box, double mult);
// Box operator*(double mult, const Box& box);

int equal(box* b1, box* b2);
int not_equal(box* b1, box* b2);

void copy_ctor(box* b1 , box* b2);


#endif